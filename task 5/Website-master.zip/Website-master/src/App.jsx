import React from 'react'
import Homepage from './components/Homepage'

const App = () => {
  return (
    <div>
      <Homepage/>
    </div>
  )
}

export default App